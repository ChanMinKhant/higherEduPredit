import React from 'react';
import './PredictionResult.css';
import { getConfigs } from '../services/modalConfig';

interface PredictionResultProps {
  prediction: {
    predicted_grade: number;
    pass_fail: string;
    probability_fail: number;
    probability_pass: number;
    confidence: string;
    higher_education: string;
    higher_education_yes: number;
    higher_education_no: number;
  };
}

const PredictionResult: React.FC<PredictionResultProps> = ({ prediction }) => {
  const [basedScore, setBasedScore] = React.useState(20);
  const [config, setConfig] = React.useState<any>({
    difficulty: 0.7,
    max_depth: 50,
    min_samples_leaf: 10,
    min_samples_split: 20,
    n_estimators: 500
  });

  React.useEffect(() => {
    const fetchBasedScore = async () => {
      try {
        const response = await getConfigs();
        const score = response.config.basedScore || 20;
        setBasedScore(score);
        setConfig(response.config);
      } catch (error) {
        console.error("Error fetching basedScore:", error);
        setBasedScore(20);
      }
    };
    fetchBasedScore();
  }, []);
  const getGradeColor = (grade: number) => {
    if (grade >= 15) return '#27ae60';
    if (grade >= 10) return '#f39c12';
    return '#e74c3c';
  };
  
  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case 'high': return '#27ae60';
      case 'moderate': return '#f39c12';
      case 'low': return '#e74c3c';
      default: return '#95a5a6';
    }
  };

  const getHigherEducationColor = (value: number) => {
    if (value == 1) return '#27ae60';
    if (value == 0) return '#f39c12';
    return '#e74c3c';
  };

  return (
    <div className="prediction-result">
      <h2>Prediction Results</h2>
      
      <div className="result-cards">
        {/* <div className="result-card grade-card">
          <h3>Predicted Grade</h3>
          <div 
            className="grade-value"
            style={{ color: getGradeColor(prediction.predicted_grade) }}
          >
            {prediction.predicted_grade}/{basedScore}
          </div>
          <div className="grade-bar">
            <div 
              className="grade-fill"
              style={{ 
                width: `${(prediction.predicted_grade / basedScore) * 100}%`,
                backgroundColor: getGradeColor(prediction.predicted_grade)
              }}
            />
          </div>
        </div> */}

        <div className="result-card status-card">
          <h3>Pass/Fail Status</h3>
          <div 
            className={`status-value ${prediction.pass_fail}`}
          >
            {prediction.pass_fail.toUpperCase()}
          </div>
          <div className="status-description">
            {prediction.pass_fail === 'pass' 
              ? 'Student is predicted to pass the course'
              : 'Student is predicted to fail the course'
            }
          </div>
        </div>

        <div className="result-card probability-card">
          <h3>Confidence Level</h3>
          <div 
            className="confidence-value"
            style={{ color: getConfidenceColor(prediction.confidence) }}
          >
            {prediction.confidence.toUpperCase()}
          </div>
          <div className="probability-details">
            <div className="prob-item">
              <span>Pass: </span>
              <span className="prob-value pass">
                {(prediction.probability_pass * 100).toFixed(1)}%
              </span>
            </div>
            <div className="prob-item">
              <span>Fail: </span>
              <span className="prob-value fail">
                {(prediction.probability_fail * 100).toFixed(1)}%
              </span>
            </div>
          </div>
        </div>

        {/* higher education card use also color */}
        <div className="result-card higher-education-card">
          <h3>Higher Education Prediction</h3>
          <div className={`higher-education-value ${prediction.higher_education}`}>
            {prediction.higher_education.toUpperCase()}
          </div>
          <div className="higher-education-details">
            <div className="higher-education-item">
              <span>Yes: </span>
              <span className="higher-education-value yes">
                {prediction.higher_education_yes}%
              </span>
            </div>
            <div className="higher-education-item">
              <span>No: </span>
              <span className="higher-education-value no">
                {prediction.higher_education_no}%
              </span>
            </div>
          </div>  
        </div>
      </div>


      <div className="interpretation">
        <h3>Interpretation</h3>
        <div className="interpretation-text">
          {prediction.pass_fail === "pass" ? (
            <p>
              ✅ The student is predicted to <strong>pass</strong> the exam{' '}
            </p>
          ) : (
            <p>
              ❌ The student is predicted to <strong>fail</strong> the exam
            </p>
          )}
          <p>
            Confidence in this prediction is{' '}
            <strong style={{ color: prediction.pass_fail === "fail" ? "red" : "green" }}>
              {prediction.confidence}
            </strong>{' '}
            ({(Math.max(prediction.probability_pass, prediction.probability_fail) * 100).toFixed(1)}%).
          </p>
        </div>
      </div>
    </div>
  );
};

export default PredictionResult;